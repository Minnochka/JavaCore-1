package sample;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

public class Controller {

    @FXML
    TextArea textAreaField;

    @FXML
    TextField textField;

    @FXML
    ToggleGroup style;

    @FXML
    RadioButton RadioBtnPink;

    @FXML
    RadioButton RadioBtnBlue;

    @FXML
    RadioButton RadioBtnGreen;

    @FXML
    RadioButton RadioBtnGrey;

    @FXML
    RadioButton RadioBtnYellow;

    @FXML
    RadioButton RadioBtnNone;

    @FXML
    VBox test;

    public void SendMsg() {
        //LocalDateTime timeNow = LocalDateTime.now();
        //SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        //String dateStr = dateFormat.format(timeNow);
        Date dateNow = new Date();
        SimpleDateFormat formatForDateNow = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
        String dateStr = formatForDateNow.format(dateNow);
        System.out.println(dateStr);
        textAreaField.appendText("\n" + "User " + dateStr + "\n" + textField.getText() + "\n");
        textField.clear();
        textField.requestFocus();
    }

    public void NewStyle() {
        if(RadioBtnPink.isSelected()){
            test.getStylesheets().clear();
            test.getStylesheets().add("./css/Style_pink.css");
        }
        else if(RadioBtnBlue.isSelected()){
            test.getStylesheets().clear();
            test.getStylesheets().add("./css/Style_blue.css");
        }
        else if(RadioBtnGreen.isSelected()){
            test.getStylesheets().clear();
            test.getStylesheets().add("./css/Style_green.css");
        }
        else if(RadioBtnGrey.isSelected()){
            test.getStylesheets().clear();
            test.getStylesheets().add("./css/Style_grey.css");
        }
        else if(RadioBtnYellow.isSelected()){
            test.getStylesheets().clear();
            test.getStylesheets().add("./css/Style_yellow.css");
        }
        else {
            test.getStylesheets().clear();
            test.getStylesheets().add("./css/Style.css");
        }
    }
}
